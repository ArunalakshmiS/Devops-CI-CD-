# DevOps CI/CD Pipeline Project

A beginner-friendly DevOps project demonstrating containerization, CI/CD automation, and Kubernetes deployment.

## Tools
- Git & GitHub
- Docker
- Docker Compose
- GitHub Actions
- Jenkins
- Kubernetes
- Node.js / Express

## Project Flow

Developer -> GitHub -> GitHub Actions / Jenkins -> Docker Image -> Kubernetes

## Run locally

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Run with Docker

```bash
docker build -t devops-demo .
docker run -p 3000:3000 devops-demo
```

## Run with Docker Compose

```bash
docker compose up --build
```

## Kubernetes

```bash
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl get pods
kubectl get services
```

This is a portfolio/learning project demonstrating common DevOps tools and workflow.
