const assert = require("assert");

function healthStatus() {
  return "UP";
}

assert.strictEqual(healthStatus(), "UP");
console.log("All tests passed.");
