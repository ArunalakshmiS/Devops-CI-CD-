# DevOps Tools Used

## Git and GitHub
Version control and remote source-code hosting.

## Docker
Packages the Node.js application and its dependencies into a container.

## Docker Compose
Runs the application using a simple Compose configuration.

## GitHub Actions
Automatically installs dependencies, runs tests, and builds the Docker image after code changes.

## Jenkins
Provides an alternative CI pipeline using a Jenkinsfile.

## Kubernetes
Deploys two application replicas and exposes them through a Kubernetes Service.

## CI/CD Flow

1. Developer pushes code to GitHub.
2. GitHub Actions starts automatically.
3. Dependencies are installed.
4. Tests are executed.
5. Docker image is built.
6. The image can then be deployed to Kubernetes.
