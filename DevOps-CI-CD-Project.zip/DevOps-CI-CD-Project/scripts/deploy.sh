#!/bin/sh
set -e

echo "Building Docker image..."
docker build -t devops-demo:latest .

echo "Starting container..."
docker rm -f devops-demo 2>/dev/null || true
docker run -d --name devops-demo -p 3000:3000 devops-demo:latest

echo "Deployment completed."
